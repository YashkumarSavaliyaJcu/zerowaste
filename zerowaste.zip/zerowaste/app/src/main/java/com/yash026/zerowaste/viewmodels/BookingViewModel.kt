package com.yash026.zerowaste.viewmodels

import android.annotation.SuppressLint
import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.util.Log
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.core.content.ContextCompat.getSystemService
import androidx.lifecycle.*
import com.yash026.zerowaste.model.Booking
import com.yash026.zerowaste.notification.Notification
import com.yash026.zerowaste.notification.messageExtra
import com.yash026.zerowaste.notification.notificationID
import com.yash026.zerowaste.notification.titleExtra
import com.yash026.zerowaste.utils.BookingApplication
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import kotlin.jvm.java

class BookingViewModel(private val repository: BookingRepository) : ViewModel() {

    val allBookings: LiveData<List<Booking>> = repository.allBookings

    fun insert(booking: Booking) = viewModelScope.launch {
        repository.insert(booking)

        scheduleNotificationWithService(booking)

    }

    @SuppressLint("ScheduleExactAlarm")
    private fun scheduleNotificationWithService(book: Booking) {
        // Create an intent for the Notification BroadcastReceiver
        val intent = Intent(
            BookingApplication.mInstance, Notification::class.java
        )

        // Extract title and message from user input
        val title = book.time
        val message = book.title

        // Add title and message as extras to the intent
        intent.putExtra(titleExtra, title)
        intent.putExtra(messageExtra, message)

        // Create a PendingIntent for the broadcast
        val pendingIntent = PendingIntent.getBroadcast(
            BookingApplication.mInstance,
            notificationID,
            intent,
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        // Get the AlarmManager service
        val alarmManager =
            BookingApplication.mInstance.getSystemService(Context.ALARM_SERVICE) as AlarmManager


        Log.i("TAG###", "getTime: ${book.time}")
        Log.i("TAG###", "getTime: ${book.date}")


//         Get the selected time and schedule the notification
        val time = getTime(book)
        alarmManager.setExactAndAllowWhileIdle(
            AlarmManager.RTC_WAKEUP, time, pendingIntent
        )

        // Show an alert dialog with information
        // about the scheduled notification
        showAlert(time, title, message)
    }

    private fun showAlert(time: Long, title: String, message: String) {
        // Format the time for display
        val date = Date(time)
        val dateFormat =
            android.text.format.DateFormat.getLongDateFormat(BookingApplication.mInstance)
        val timeFormat = android.text.format.DateFormat.getTimeFormat(BookingApplication.mInstance)

//        Toast.makeText(
//            BookingApplication.mInstance,
//            "Title: $title\nMessage: $message\nAt: ${dateFormat.format(date)} ${
//                timeFormat.format(
//                    date
//                )
//            }",
//            Toast.LENGTH_SHORT
//        ).show()

        // Create and show an alert dialog with notification details
//        AlertDialog.Builder(BookingApplication.mInstance)
//            .setTitle("Notification Scheduled")
//            .setMessage(
//                "Title: $title\nMessage: $message\nAt: ${dateFormat.format(date)} ${
//                    timeFormat.format(
//                        date
//                    )
//                }"
//            )
//            .setPositiveButton("Okay") { _, _ -> }
//            .show()
    }


    private fun getTime(book: Booking): Long {

        val dateFormat = SimpleDateFormat("dd-MM-yyyy", Locale.getDefault())
        val timeFormat = SimpleDateFormat("HH:mm", Locale.getDefault())

        val date = dateFormat.parse(book.date)
        val time = timeFormat.parse(book.time)

        val calendar = Calendar.getInstance()

        date?.let {
            val tempCalendar = Calendar.getInstance()
            tempCalendar.time = it
            val day = tempCalendar.get(Calendar.DAY_OF_MONTH)
            val month = tempCalendar.get(Calendar.MONTH) // Months are 0-based
            val year = tempCalendar.get(Calendar.YEAR)

            time?.let {
                val tempTimeCalendar = Calendar.getInstance()
                tempTimeCalendar.time = it
                val hour = tempTimeCalendar.get(Calendar.HOUR_OF_DAY)
                val minute = tempTimeCalendar.get(Calendar.MINUTE)

                // Set everything at once
                calendar.set(year, month, day, hour, minute)
            }
        }
        return calendar.timeInMillis // Return timestamp as Long
    }


    fun delete(booking: Booking) = viewModelScope.launch {
        repository.delete(booking)
    }
}
