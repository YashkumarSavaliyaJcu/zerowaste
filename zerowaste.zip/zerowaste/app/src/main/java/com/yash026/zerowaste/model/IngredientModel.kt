package com.yash026.zerowaste.model

import java.io.Serializable

data class IngredientModel(
    val name: String,
    val quantity: String
): Serializable