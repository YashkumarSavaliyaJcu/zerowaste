package com.yash026.zerowaste.activities

import android.app.DatePickerDialog
import android.app.TimePickerDialog
import android.net.Uri
import android.util.Log
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavHostController
import coil.compose.rememberAsyncImagePainter
import com.yash026.zerowaste.R
import com.yash026.zerowaste.model.Booking
import com.yash026.zerowaste.utils.BookingApplication
import com.yash026.zerowaste.viewmodels.BookingViewModel
import com.yash026.zerowaste.viewmodels.BookingViewModelFactory
import java.util.Calendar

@OptIn(ExperimentalMaterial3Api::class)
//@Preview(showBackground = true)
@Composable
fun HomeScreen(
    navController: NavHostController,
    viewModel: BookingViewModel = viewModel(factory = BookingViewModelFactory((LocalContext.current.applicationContext as BookingApplication).repository))
) {


    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("All Category") },
            )
        },

        ) { innerPadding ->

        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(bottom = 65.dp, start = 15.dp, end = 15.dp),

            ) {

            var title by remember { mutableStateOf("") }
            var date by remember { mutableStateOf("Select Date") }
            var time by remember { mutableStateOf("Select Time") }
            var description by remember { mutableStateOf("") }

            var imageUri by remember { mutableStateOf<Uri?>(null) }

            val launcher = rememberLauncherForActivityResult(
                contract = ActivityResultContracts.GetContent()
            ) { uri: Uri? ->
                imageUri = uri
            }

            Box(
                modifier = Modifier.fillMaxWidth(),
                contentAlignment = Alignment.Center // Centers the image inside the Box
            ) {

                imageUri?.let {
                    Image(
                        painter = rememberAsyncImagePainter(it),
                        contentDescription = "Selected Image",
                        contentScale = ContentScale.Crop,
                        modifier = Modifier
                            .size(100.dp)
                            .clip(CircleShape)
                            .clickable { launcher.launch("image/*") })
                } ?: Box(
                    modifier = Modifier
                        .size(100.dp)
                        .clip(CircleShape)
                        .background(Color.Gray)
                        .clickable { launcher.launch("image/*") },
                    contentAlignment = Alignment.Center
                ) {
                    Image(
                        painter = painterResource(id = R.drawable.placeholder),
                        contentDescription = "Andy Rubin",
                        modifier = Modifier
                            .clip(RoundedCornerShape(50))
                            .size(100.dp)
                            .clickable { launcher.launch("image/*") },
                        contentScale = ContentScale.Crop
                    )
                }
            }

            Text(
                "Title", fontSize = 20.sp, modifier = Modifier.padding(top = 15.dp, bottom = 10.dp)
            )

            BasicTitleTextField(title) { title = it }


            Text("Date", fontSize = 20.sp, modifier = Modifier.padding(top = 15.dp, bottom = 10.dp))

            DatePickerField(date) { date = it }

            Text("Time", fontSize = 20.sp, modifier = Modifier.padding(top = 15.dp, bottom = 10.dp))

            TimePickerField(time) { time = it }

            Text(
                "Description",
                fontSize = 20.sp,
                modifier = Modifier.padding(top = 15.dp, bottom = 10.dp),
            )

            BasicDescriptionTextField(description) { description = it }


            Button(
                onClick = {

                    val booking = Booking(
                        date = date,
                        time = time,
                        image = imageUri.toString(),
                        title = title,
                        description = description
                    )
                    viewModel.insert(booking)

                    Log.d(
                        "ReminderData",
                        "Title: $title, Date: $date, Time: $time, Description: $description, imageUri: $imageUri"
                    )
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 30.dp)
                    .height(55.dp),
                shape = RoundedCornerShape(8.dp),
                enabled = true,
                contentPadding = PaddingValues(12.dp)
            ) {
                Text(text = "Reminder")
            }

        }
    }


    // List of foods
    /*
        val foodItems = listOf(
            FoodItemData(
                R.drawable.milk,
                "Milk",
                "Expires on: 25th March 2025",
                "Use for cooking before expiry."
            ),
            FoodItemData(
                R.drawable.bread,
                "Bread",
                "Expires on: 22nd March 2025",
                "Store in a cool place."
            ),
            FoodItemData(
                R.drawable.cheese,
                "Cheese",
                "Expires on: 30th March 2025",
                "Keep refrigerated."
            ),
            FoodItemData(
                R.drawable.egg,
                "Eggs",
                "Expires on: 28th March 2025",
                "Consume within 2 weeks."
            ),
            FoodItemData(R.drawable.yogurt, "Yogurt", "Expires on: 26th March 2025", "Keep chilled."),
        )
    */

    /*
        Scaffold(
            modifier = Modifier.fillMaxSize(),
            topBar = {
                TopAppBar(
                    title = {
                        Row {
                            Text("Zero Waste Tracker")
                        }

                    },
                    colors = TopAppBarDefaults.topAppBarColors(
                        containerColor = Color(0xFFbdffa2),
                        titleContentColor = Color.Black
                    ),

                    )
            },

            ) { innerPadding ->
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
            ) {
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(16.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(foodItems) { food ->
                        FoodItem(
                            imageRes = food.imageRes,
                            title = food.title,
                            expiryDate = food.expiryDate,
                            note = food.note
                        )
                    }
                }
            }
        }
    */

}

@Composable
fun BasicTitleTextField(title: String, onTitleChange: (String) -> Unit) {


    Box(
        modifier = Modifier
            .border(1.dp, Color.Gray, shape = RoundedCornerShape(8.dp)) // Add border
            .fillMaxWidth()
            .padding(8.dp) // Add padding inside border
    ) {
        BasicTextField(
            value = title,
            onValueChange = { onTitleChange(it) },
            textStyle = TextStyle(fontSize = 18.sp, color = Color.Black),
            modifier = Modifier
                .fillMaxWidth()
                .padding(8.dp),
            decorationBox = { innerTextField ->
                if (title.isEmpty()) {
                    Text("Title", color = Color.Gray) // Placeholder text
                }
                innerTextField()
            })
    }
}


@Composable
fun BasicDescriptionTextField(title: String, onTitleChange: (String) -> Unit) {


    Box(
        modifier = Modifier
            .border(1.dp, Color.Gray, shape = RoundedCornerShape(8.dp)) // Add border
            .fillMaxWidth()
            .padding(8.dp) // Add padding inside border
    ) {
        BasicTextField(
            value = title,
            onValueChange = { onTitleChange(it) },
            textStyle = TextStyle(fontSize = 18.sp, color = Color.Black),
            modifier = Modifier
                .fillMaxWidth()
                .padding(8.dp),
            decorationBox = { innerTextField ->
                if (title.isEmpty()) {
                    Text("Description", color = Color.Gray) // Placeholder text
                }
                innerTextField()
            })
    }
}


@Composable
fun DatePickerField(date: String, onDateSelected: (String) -> Unit) {

    var showDatePicker by remember { mutableStateOf(false) }
    val context = LocalContext.current

    if (showDatePicker) {
        val calendar = Calendar.getInstance()
        DatePickerDialog(
            context,
            { _, year, month, dayOfMonth ->
                val selectedDate = String.format("%04d-%02d-%02d", year, month + 1, dayOfMonth)
                onDateSelected(selectedDate)
                showDatePicker = false
            },
            calendar.get(Calendar.YEAR),
            calendar.get(Calendar.MONTH),
            calendar.get(Calendar.DAY_OF_MONTH)
        ).apply {
            setOnDismissListener { showDatePicker = false }
            show()
        }
    }

    Box(
        modifier = Modifier
            .border(1.dp, Color.Black, shape = RoundedCornerShape(8.dp)) // Border
        .height(55.dp)
            .fillMaxWidth()
            .clickable { showDatePicker = true } // Click to show DatePicker
        .padding(start = 15.dp), contentAlignment = Alignment.CenterStart // Align text to start
    ) {
        Text(
            text = date, // Set selected date text
            fontSize = 18.sp, color = Color.Black
        )
    }
}


@Composable
fun TimePickerField(time: String, onDateSelected: (String) -> Unit) {

    var showTimePicker by remember { mutableStateOf(false) }
    val context = LocalContext.current

    if (showTimePicker) {
        val calendar = Calendar.getInstance()
        TimePickerDialog(
            context,
            { _, hourOfDay, minute ->
                val selectedTime = String.format("%02d:%02d", hourOfDay, minute)
                onDateSelected(selectedTime)
                showTimePicker = false
            },
            calendar.get(Calendar.HOUR_OF_DAY),
            calendar.get(Calendar.MINUTE),
            true // 24-hour format
        ).apply {
            setOnDismissListener { showTimePicker = false }
            show()
        }
    }

    Box(
        modifier = Modifier
            .border(1.dp, Color.Black, shape = RoundedCornerShape(8.dp)) // Border
        .height(55.dp)
            .fillMaxWidth()
            .clickable { showTimePicker = true } // Opens Time Picker
        .padding(start = 15.dp), contentAlignment = Alignment.CenterStart) {
        Text(
            text = time, // Show selected time
            fontSize = 18.sp, color = Color.Black
        )
    }
}

