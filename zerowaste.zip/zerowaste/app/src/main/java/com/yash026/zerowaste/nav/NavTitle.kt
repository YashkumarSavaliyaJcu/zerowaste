package com.yash026.zerowaste.nav

object NavTitle {
    const val HOME = "Home"
    const val List = "List"
    const val RECIPE = "Recipe"
}