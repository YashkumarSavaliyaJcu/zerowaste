package com.yash026.zerowaste.database

import androidx.lifecycle.LiveData
import androidx.room.*
import com.yash026.zerowaste.model.Booking


@Dao
interface BookingDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(booking: Booking)

    @Query("SELECT * FROM booking_table ORDER BY id DESC")
    fun getAllBookings(): LiveData<List<Booking>>

    @Delete
    suspend fun deleteBooking(booking: Booking)

}
