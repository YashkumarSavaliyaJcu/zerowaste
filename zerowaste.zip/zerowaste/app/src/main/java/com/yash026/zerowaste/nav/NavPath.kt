package com.yash026.zerowaste.nav

enum class NavPath {
    HOME, ITEMS, PROFILE
}