package com.yash026.zerowaste.viewmodels

import androidx.lifecycle.LiveData
import com.yash026.zerowaste.database.BookingDao
import com.yash026.zerowaste.model.Booking

class BookingRepository(private val bookingDao: BookingDao) {

    val allBookings: LiveData<List<Booking>> = bookingDao.getAllBookings()

    suspend fun insert(booking: Booking) {
        bookingDao.insert(booking)
    }

    suspend fun delete(booking: Booking) {
        bookingDao.deleteBooking(booking)
    }
}
