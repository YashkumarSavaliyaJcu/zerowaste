package com.yash026.zerowaste.utils

class Utils {

}